package com.example.weighttrackingapp_option_3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button submitButton;
    private Button createAccountButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        submitButton = findViewById(R.id.submitLogin);
    }

    public void submitLogin (View view) {
        setContentView(R.layout.input_weight);
    }

    public void setCreateAccount (View view) {
        setContentView(R.layout.create_account);
    }

}
